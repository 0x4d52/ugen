/** 
 @page		Tutorial_XX_XX		Tutorial XX.XX: Name

 This tutorial ...
 
 
 prev: @ref Tutorial_XX_XX	"Tutorial XX.XX: Name"
 
 next: @ref Tutorial_XX_XX	"Tutorial XX.XX: Name"
*/